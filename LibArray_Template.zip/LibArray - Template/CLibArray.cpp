#include "stdafx.h"

#include <memory.h>

#include "CLibArray.h"
