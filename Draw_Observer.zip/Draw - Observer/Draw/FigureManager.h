#ifndef _FIGUREMANAGER_H_
#define _FIGUREMANAGER_H_

#include <iostream>
#include <list>

using std::list; 

class BlackBoard; 

class Observable; 
class Observer
{
public:
	virtual void update(Observable *observable) = 0; 
	virtual ~Observer() { }
};

class Observable
{
public:
	typedef list<Observer *> Observers; 

public:
	void notify()
	{
		for (Observers::iterator iter = _observers.begin(); iter != _observers.end(); ++iter)
		{
			(*iter)->update(this); 
		}
	}

	void register_observer(Observer *observer)
	{
		_observers.push_back(observer); 
	}

	virtual ~Observable() { }
private:
	Observers _observers; 

};

//////////////////////////////////////////////////////////////////////////
class Data : public Observable
{
public:
	Data(int _x, int _y) : x(_x), y(_y) { }

	int get_x() const { return x; }
	int get_y() const { return y; }

	void set_x(int _x) { x = _x; notify(); }
	void set_y(int _y) { y = _y; notify(); }

private:
	int x;
	int y; 
};

class TextView : public Observer
{
public:
	virtual void update(Observable *observable)
	{
		// Data *data = static_cast<Data *>(observable); 
		// draw(*data); 

		Data *data = dynamic_cast<Data *>(observable); 
		if (data != NULL)
		{
			draw(*data); 
		}

	}
	void draw(const Data &data); 

};

class GuiView : public Observer
{
public:
	virtual void update(Observable *observable); 
	void draw(const Data &data, BlackBoard &board); 
};

class GuiView2 : public Observer
{
public:
	virtual void update(Observable *observable); 
	void draw(const Data &data, BlackBoard &board); 
};


#if 0
class TextView; 
class GuiView; 

class Data
{
public:
	Data(int _x, int _y, TextView *tview, GuiView *gview) : x(_x), y(_y), _tview(tview), _gview(gview){ }

	int get_x() const { return x; }
	int get_y() const { return y; }

	void set_x(int _x); 
	void set_y(int _y); 

private:
	int x;
	int y; 

	TextView *_tview; 
	GuiView *_gview; 

};

class TextView
{
public:
	void draw(const Data &data); 

};

class GuiView
{
public:
	void draw(const Data &data); 
};
#endif


class FigureManager
{
public:
	static FigureManager &handle()
	{
		static FigureManager manager; 
		return manager; 
	}
    
    // FigureManager����������
    virtual ~FigureManager() { }
 
    // FigureManager��ӿ�.
public:
	FigureManager() : _data(0, 0) 
	{
		_data.register_observer(&_tview); 
		_data.register_observer(&_gview); 
		_data.register_observer(&_gview2); 
	}

	void setBlackboard(BlackBoard *board)
	{
		_board = board; 
	}

    void display(BlackBoard &board); 

	void onLeft()
	{
		_data.set_x(_data.get_x() - 5); 
	}

	void onRight()
	{
		_data.set_x(_data.get_x() + 5); 
	}

	void onUp()
	{
		_data.set_y(_data.get_y() + 5); 
	}
	
	void onDown()
	{
		_data.set_y(_data.get_y() - 5); 
	}

	void onUpdateWindow(); 

private:
	TextView _tview; 
	GuiView _gview; 
	GuiView2 _gview2; 

	Data _data;

	BlackBoard *_board; 

}; // class FigureManager�ඨ�����.

void InitiateFigureManager(); 

#endif // #ifndef _FIGUREMANAGER_H_
